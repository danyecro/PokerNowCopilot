import type { ExtMessage } from '../shared/messages';
import type { GameState, PlayerStats } from '../shared/types';
import { boardToString, cardToString } from '../parser/cardUtils';
import { getBadgeColor } from '../ui/colors';
import { computeEdgeHints } from '../shared/edgeIndicator';

let port: chrome.runtime.Port | null = null;
let currentStats: Record<string, PlayerStats> = {};
let currentHeroStats: PlayerStats | null = null;
let currentGameState: GameState | null = null;
let aiBuffer = '';
let analyzing = false;
let totalHands = 0;

// ── Connection ──────────────────────────────────────────────────────────────
function connect(): void {
  port = chrome.runtime.connect({ name: 'sidepanel' });
  port.onMessage.addListener(onMessage);
  port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 1000); });
}

// ── Messages ────────────────────────────────────────────────────────────────
function onMessage(msg: ExtMessage): void {
  switch (msg.type) {
    case 'STATS_UPDATE':
      currentStats = msg.stats;
      totalHands = Math.max(0, ...Object.values(msg.stats).map(s => s.handsSeen));
      renderOpponents();
      renderEdgeHints();
      break;
    case 'HERO_STATS_UPDATE':
      currentHeroStats = msg.stats;
      renderHeroStats();
      break;
    case 'GAME_STATE_UPDATE':
    case 'PULL_RESPONSE':
      currentGameState = msg.gameState;
      renderHandBar();
      renderEdgeHints();
      unlockPullButtons();
      break;
    case 'AI_STREAM_START': {
      const output = document.getElementById('ai-output');
      if (output) output.textContent = '';
      aiBuffer = '';
      setAnalyzing(true);
      setStatus(msg.label ?? 'Streaming…', 'streaming');
      break;
    }
    case 'AI_STREAM_CHUNK':
      appendAiChunk(msg.chunk);
      break;
    case 'AI_STREAM_DONE':
      setAnalyzing(false); setStatus('');
      break;
    case 'AI_STREAM_ERROR':
      setAnalyzing(false); setStatus(msg.error, 'error');
      break;
  }
}

// ── Pull Buttons ─────────────────────────────────────────────────────────────
document.querySelectorAll<HTMLButtonElement>('.pull-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.dataset['pull'] as 'hand' | 'board' | 'pot' | 'bets' | 'all';
    btn.classList.add('pulling');
    btn.disabled = true;
    chrome.runtime.sendMessage({ type: 'PULL_REQUEST', target } as ExtMessage);
    // Timeout fallback — re-enable if no response within 3s
    setTimeout(() => { btn.classList.remove('pulling'); btn.disabled = false; }, 3000);
  });
});

function unlockPullButtons(): void {
  document.querySelectorAll<HTMLButtonElement>('.pull-btn').forEach(b => {
    b.classList.remove('pulling'); b.disabled = false;
  });
}

// ── Render: Hand Bar ─────────────────────────────────────────────────────────
function renderHandBar(): void {
  const gs = currentGameState;
  if (!gs) return;
  setText('val-hero-cards', gs.heroCards
    ? `${cardToString(gs.heroCards[0])} ${cardToString(gs.heroCards[1])}`
    : '—');
  setText('val-board', gs.board.length > 0 ? boardToString(gs.board) : '—');
  setText('val-pot', gs.pot > 0 ? String(gs.pot) : '—');
  setText('val-street', gs.street);
}

// ── Render: Edge Hints ────────────────────────────────────────────────────────
function renderEdgeHints(): void {
  const el = document.getElementById('edge-list');
  if (!el) return;
  if (!currentGameState) {
    el.innerHTML = '<span class="placeholder">Pull the table state to see edge hints.</span>';
    return;
  }
  const hints = computeEdgeHints(currentGameState, currentStats);
  if (hints.length === 0) {
    el.innerHTML = '<span class="placeholder">No specific edges detected — play standard.</span>';
    return;
  }
  el.innerHTML = hints.map(h =>
    `<div class="edge-hint ${h.type}"><span class="edge-icon">${h.icon}</span><span>${esc(h.text)}</span></div>`
  ).join('');
}

// ── Render: Opponents ─────────────────────────────────────────────────────────
function renderOpponents(): void {
  const list = document.getElementById('opponent-list');
  const label = document.getElementById('hands-seen-label');
  if (!list) return;
  if (label) label.textContent = totalHands > 0 ? `(${totalHands} hands)` : '';

  const opponents = Object.values(currentStats);
  if (opponents.length === 0) {
    list.innerHTML = '<span class="placeholder" style="padding:6px 10px">Play a few hands to collect data.</span>';
    return;
  }

  // Players currently seated at the table (from last pull / game state)
  const atTableIds = new Set(
    (currentGameState?.seats ?? [])
      .filter(s => !s.isHero)
      .map(s => s.playerId)
  );

  opponents.sort((a, b) => {
    const aAt = atTableIds.has(a.playerId) ? 0 : 1;
    const bAt = atTableIds.has(b.playerId) ? 0 : 1;
    if (aAt !== bAt) return aAt - bAt;   // current players first
    return b.handsSeen - a.handsSeen;    // then by hands seen desc
  });
  let lastWasAtTable = true;
  list.innerHTML = opponents.map(s => {
    const isAtTable = atTableIds.has(s.playerId);
    let separator = '';
    if (lastWasAtTable && !isAtTable && atTableIds.size > 0) {
      separator = `<div class="opp-separator">── history ──</div>`;
    }
    lastWasAtTable = isAtTable;

    const color = getBadgeColor(s);
    const dot = colorToCss(color);
    const hasData = s.handsSeen >= 3;
    if (!hasData) return `${separator}
      <div class="opp-row no-data">
        <div class="opp-name"><span class="opp-color-dot" style="background:${dot}"></span>${esc(s.displayName)}</div>
        <div class="opp-stats">n=${s.handsSeen} — collecting</div>
        <div></div>
      </div>`;

    const v = Math.round(s.vpip * 100), p = Math.round(s.pfr * 100);
    const tb = Math.round(s.threeBet * 100), fc = Math.round(s.foldToCbet * 100);
    const af = s.af.toFixed(1);
    const vC = v > 42 ? 'call' : v < 20 ? 'cold' : '';
    const pC = p > 25 ? 'hot' : '';
    const afC = parseFloat(af) > 3 ? 'hot' : '';
    const tags = s.tags.slice(0, 2).join(' · ');

    return `${separator}<div class="opp-row${isAtTable ? ' at-table' : ''}">
      <div class="opp-name"><span class="opp-color-dot" style="background:${dot}"></span>${esc(s.displayName)}</div>
      <div class="opp-stats">
        <div class="opp-stat-row">
          <span class="stat-chip ${vC}" title="VPIP">V${v}%</span>
          <span class="stat-chip ${pC}" title="PFR">P${p}%</span>
          <span class="stat-chip" title="3Bet">3B${tb}%</span>
          <span class="stat-chip ${afC}" title="Aggression Factor">AF${af}</span>
          <span class="stat-chip" title="Fold to CBet">F↳${fc}%</span>
        </div>
        ${tags ? `<div class="opp-tags">${esc(tags)}</div>` : ''}
      </div>
      <div class="opp-n">n=${s.handsSeen}</div>
    </div>`;
  }).join('');
}

// ── Render: Hero Stats ────────────────────────────────────────────────────────
function renderHeroStats(): void {
  const el = document.getElementById('hero-stats-content');
  if (!el) return;
  const s = currentHeroStats;
  if (!s || s.handsSeen < 1) {
    el.innerHTML = '<span class="placeholder">Play hands to track your own stats.</span>';
    return;
  }
  const v = Math.round(s.vpip * 100), p = Math.round(s.pfr * 100);
  const tb = Math.round(s.threeBet * 100), fc = Math.round(s.foldToCbet * 100);
  const af = s.af.toFixed(1);
  el.innerHTML = `
    <div class="hero-stat-row">
      <span class="stat-chip" title="VPIP">V:${v}%</span>
      <span class="stat-chip" title="PFR">P:${p}%</span>
      <span class="stat-chip" title="3Bet">3B:${tb}%</span>
      <span class="stat-chip" title="AF">AF:${af}</span>
      <span class="stat-chip" title="Fold to CBet">F↳:${fc}%</span>
      <span class="stat-chip" style="color:#6b7280">n=${s.handsSeen}</span>
    </div>
    ${s.tags.length ? `<div class="opp-tags" style="margin-top:3px">You: ${esc(s.tags.join(' · '))}</div>` : ''}
  `;
}

// ── AI ────────────────────────────────────────────────────────────────────────
function appendAiChunk(chunk: string): void {
  const output = document.getElementById('ai-output');
  if (!output) return;
  aiBuffer += chunk;
  output.textContent = aiBuffer;
  setStatus('Streaming…', 'streaming');
  output.scrollTop = output.scrollHeight;
}

document.getElementById('btn-analyze')?.addEventListener('click', () => {
  if (!currentGameState || analyzing) return;
  const output = document.getElementById('ai-output');
  if (output) output.textContent = '';
  aiBuffer = '';
  setAnalyzing(true);
  setStatus('Requesting analysis…', 'streaming');
  chrome.runtime.sendMessage({
    type: 'AI_ANALYZE_REQUEST',
    gameState: currentGameState,
    stats: currentStats,
  } as ExtMessage);
});

document.getElementById('btn-settings')?.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function setText(id: string, text: string): void {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}
function setStatus(msg: string, type = ''): void {
  const el = document.getElementById('ai-status');
  if (!el) return; el.textContent = msg; el.className = type;
}
function setAnalyzing(on: boolean): void {
  analyzing = on;
  const btn = document.getElementById('btn-analyze') as HTMLButtonElement | null;
  if (btn) { btn.disabled = on; btn.textContent = on ? 'Analyzing…' : 'Analyze moves'; }
}
function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function colorToCss(color: string): string {
  return ({ red:'#e74c3c', blue:'#3498db', yellow:'#f1c40f', gray:'#6b7280' } as Record<string,string>)[color] ?? '#6b7280';
}

connect();

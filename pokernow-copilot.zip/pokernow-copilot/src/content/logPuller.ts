import { SEL } from './selectors';
import { LOG_MODAL_TIMEOUT_MS } from '../shared/constants';

let pulling = false;

export async function pullLogEntries(): Promise<Element[]> {
  if (pulling) return [];
  pulling = true;

  try {
    const openBtn =
      document.querySelector<HTMLElement>(SEL.LOG_OPEN_BUTTON) ??
      document.querySelector<HTMLElement>('.log-button-container button') ??
      document.querySelector<HTMLElement>('.log-button-container') as HTMLElement | null;

    if (!openBtn) {
      console.warn('[Copilot] Log open button not found');
      return [];
    }

    injectHideStyle();
    reactClick(openBtn);

    const modal = await waitForElement(SEL.LOG_MODAL, LOG_MODAL_TIMEOUT_MS);
    if (!modal) {
      console.warn('[Copilot] Log modal did not appear within timeout');
      removeHideStyle();
      return [];
    }

    // Wait for React to finish rendering all entries (modal appears before entries populate)
    await waitForEntriesStable(modal);

    const entriesContainer = modal.querySelector(SEL.LOG_ENTRIES);
    if (!entriesContainer) {
      closeModal();
      return [];
    }

    const entries = Array.from(entriesContainer.querySelectorAll(SEL.LOG_ENTRY));
    closeModal();
    return entries;
  } finally {
    pulling = false;
    removeHideStyle();
  }
}

/**
 * Waits until the entry count in the modal stops growing for 200ms,
 * or until a maximum wait of 1500ms.
 */
function waitForEntriesStable(modal: Element): Promise<void> {
  return new Promise(resolve => {
    const MAX_WAIT = 1500;
    const STABLE_DELAY = 200;
    let lastCount = -1;
    let stableTimer: ReturnType<typeof setTimeout> | null = null;
    const deadline = setTimeout(() => {
      if (stableTimer) clearTimeout(stableTimer);
      observer.disconnect();
      resolve();
    }, MAX_WAIT);

    const observer = new MutationObserver(() => {
      const count = modal.querySelectorAll(SEL.LOG_ENTRY).length;
      if (count !== lastCount) {
        lastCount = count;
        if (stableTimer) clearTimeout(stableTimer);
        stableTimer = setTimeout(() => {
          clearTimeout(deadline);
          observer.disconnect();
          resolve();
        }, STABLE_DELAY);
      }
    });

    observer.observe(modal, { childList: true, subtree: true });

    // Kick off initial check
    const count = modal.querySelectorAll(SEL.LOG_ENTRY).length;
    lastCount = count;
    stableTimer = setTimeout(() => {
      clearTimeout(deadline);
      observer.disconnect();
      resolve();
    }, STABLE_DELAY);
  });
}

function reactClick(el: HTMLElement): void {
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
  el.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, cancelable: true, view: window }));
  el.dispatchEvent(new MouseEvent('click',     { bubbles: true, cancelable: true, view: window }));
}

function waitForElement(selector: string, timeoutMs: number): Promise<Element | null> {
  return new Promise(resolve => {
    const existing = document.querySelector(selector);
    if (existing) { resolve(existing); return; }

    const observer = new MutationObserver(() => {
      const el = document.querySelector(selector);
      if (el) { observer.disconnect(); clearTimeout(timer); resolve(el); }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    const timer = setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, timeoutMs);
  });
}

function closeModal(): void {
  const closeBtn =
    document.querySelector<HTMLElement>(SEL.LOG_CLOSE_BUTTON) ??
    document.querySelector<HTMLElement>('.modal.log-modal .modal-button-close') ??
    document.querySelector<HTMLElement>('.log-modal button[class*="close"]');
  if (closeBtn) reactClick(closeBtn);
}

const HIDE_STYLE_ID = 'copilot-log-hide';

function injectHideStyle(): void {
  if (document.getElementById(HIDE_STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = HIDE_STYLE_ID;
  style.textContent = `.modal.log-modal { opacity: 0 !important; pointer-events: none !important; }`;
  document.head.appendChild(style);
}

function removeHideStyle(): void {
  document.getElementById(HIDE_STYLE_ID)?.remove();
}

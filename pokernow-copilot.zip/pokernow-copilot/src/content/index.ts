import { healthCheck, SEL } from './selectors';
import { startWatching } from './domWatcher';
import { pullLogEntries } from './logPuller';
import { snapshotGameState } from './gameStateReader';
import { extractLastHandLines, parseHand } from '../parser/handParser';
import {
  ingestHand, updateNameMap, getAllStats, getHeroStatsSnapshot,
  loadFromStorage, setHeroPlayerId,
} from '../stats/statsEngine';
import { updateOverlays, setOverlaysEnabled, removeAllBadges } from './overlayManager';
import { startPopoverWatcher } from './popoverWatcher';
import type { ExtMessage, PullRequestMessage } from '../shared/messages';

async function init(): Promise<void> {
  await waitForGameRoot();
  if (!healthCheck()) return;

  // Load persisted stats (chrome.storage.local accessible in content scripts)
  await loadFromStorage();

  // Detect hero player ID
  const heroLink = document.querySelector<HTMLAnchorElement>(`${SEL.HERO} .table-player-name a`);
  const heroId = heroLink?.getAttribute('href')?.split('/').pop() ?? '';
  if (heroId) setHeroPlayerId(heroId);

  setOverlaysEnabled(true);
  // Also do an initial overlay render with whatever stats are already loaded
  updateOverlays(getAllStats(), (pid) => chrome.runtime.sendMessage({ type: 'EXPLOIT_REQUEST', playerId: pid, stats: getAllStats() }));
  startWatching(onHandEnd);
  startPopoverWatcher(getAllStats);

  // Listen for pull requests from the side panel (routed via background)
  chrome.runtime.onMessage.addListener((msg: ExtMessage, _sender, sendResponse) => {
    if (msg.type === 'PULL_REQUEST') {
      handlePullRequest(msg as PullRequestMessage, sendResponse);
      return true; // keep channel open for async response
    }
  });

  console.log('[PokerNow Copilot] Active — hero:', heroId || '(unknown)');
}

function handlePullRequest(
  msg: PullRequestMessage,
  sendResponse: (r: { gameState: ReturnType<typeof snapshotGameState>['gameState'] }) => void,
): void {
  const { gameState, nameToIdMap } = snapshotGameState();
  updateNameMap(nameToIdMap);
  sendResponse({ gameState });
}

async function onHandEnd(): Promise<void> {
  const { gameState, nameToIdMap } = snapshotGameState();
  updateNameMap(nameToIdMap);

  const entries = await pullLogEntries();
  if (entries.length === 0) return;

  const lines = extractLastHandLines(entries);
  console.log('[Copilot] Raw log lines:', lines);

  const hand = parseHand(lines);
  if (!hand) {
    console.warn('[Copilot] Could not parse hand', lines);
    return;
  }
  console.log('[Copilot] Hand parsed:', hand);

  const { opponentStats, heroStats } = ingestHand(hand);
  updateOverlays(opponentStats, (pid) => chrome.runtime.sendMessage({ type: 'EXPLOIT_REQUEST', playerId: pid, stats: opponentStats }));

  chrome.runtime.sendMessage({ type: 'STATS_UPDATE', stats: opponentStats } as ExtMessage);
  chrome.runtime.sendMessage({ type: 'GAME_STATE_UPDATE', gameState } as ExtMessage);
  if (heroStats) {
    chrome.runtime.sendMessage({ type: 'HERO_STATS_UPDATE', stats: heroStats } as ExtMessage);
  }
}

function waitForGameRoot(): Promise<void> {
  return new Promise(resolve => {
    if (document.querySelector('.game-main-container')) { resolve(); return; }
    const obs = new MutationObserver(() => {
      if (document.querySelector('.game-main-container')) { obs.disconnect(); resolve(); }
    });
    obs.observe(document.body, { childList: true, subtree: true });
    setTimeout(resolve, 10000);
  });
}

init().catch(console.error);

import { SEL } from './selectors';
import { HAND_END_DEBOUNCE_MS } from '../shared/constants';

type HandEndCallback = () => void;

let observer: MutationObserver | null = null;
let debounceTimer: ReturnType<typeof setTimeout> | null = null;
let lastHandEndTime = 0;
let lastKnownPot = 0;
let potWasSignificant = false;
const POT_THRESHOLD = 10; // pot must have been above this to count as a real hand

export function startWatching(onHandEnd: HandEndCallback): void {
  if (observer) return;

  const seatsEl = document.querySelector(SEL.SEATS);
  if (!seatsEl) {
    console.warn('[Copilot] .seats not found, watcher not started');
    return;
  }

  observer = new MutationObserver(() => checkHandEnd(onHandEnd));

  observer.observe(seatsEl, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class'],
  });

  // Also observe pot separately
  const potContainer = document.querySelector('.table-pot-size');
  if (potContainer) {
    observer.observe(potContainer, { childList: true, subtree: true, characterData: true });
  }
}

export function stopWatching(): void {
  observer?.disconnect();
  observer = null;
  if (debounceTimer) clearTimeout(debounceTimer);
}

function readPot(): number {
  const text = document.querySelector(SEL.POT_VALUE)?.textContent?.trim().replace(/,/g, '') ?? '0';
  return parseFloat(text) || 0;
}

function checkHandEnd(onHandEnd: HandEndCallback): void {
  const pot = readPot();

  // Track whether the pot was ever significant this hand
  if (pot > POT_THRESHOLD) {
    potWasSignificant = true;
    lastKnownPot = pot;
    return; // pot is still live, definitely mid-hand
  }

  // Pot just dropped to 0 (or near 0) — but only meaningful if it was significant before
  if (pot === 0 && potWasSignificant) {
    // Confirmed hand end: pot was real and is now gone, no active bets remain
    const activeBets = document.querySelectorAll(SEL.PLAYER_BET).length;
    if (activeBets === 0) {
      scheduleHandEnd(onHandEnd);
    }
  }
}

function scheduleHandEnd(onHandEnd: HandEndCallback): void {
  if (debounceTimer) clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    const now = Date.now();
    if (now - lastHandEndTime < 5000) return; // 5s minimum between hand-end events
    lastHandEndTime = now;
    potWasSignificant = false; // reset for next hand
    lastKnownPot = 0;
    onHandEnd();
  }, HAND_END_DEBOUNCE_MS);
}

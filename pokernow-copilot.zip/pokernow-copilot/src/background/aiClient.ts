import type { GameState, PlayerStats } from '../shared/types';
import { getSettings } from '../shared/storage';
import { OPENROUTER_BASE_URL, OPENAI_BASE_URL } from '../shared/constants';
import { buildPrompt } from './promptBuilder';

let currentAbortController: AbortController | null = null;

export type StreamCallback = (chunk: string) => void;
export type DoneCallback = () => void;
export type ErrorCallback = (error: string) => void;

function resolveEndpointAndHeaders(apiKey: string, model: string): {
  url: string;
  headers: Record<string, string>;
  modelId: string;
} {
  const isOpenRouter = apiKey.startsWith('sk-or-');

  if (isOpenRouter) {
    return {
      url: OPENROUTER_BASE_URL,
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://www.pokernow.com',
        'X-Title': 'PokerNow Copilot',
      },
      modelId: model,
    };
  }

  // OpenAI key — use OpenAI API directly
  // Strip "openai/" prefix if present (OpenRouter model IDs)
  const modelId = model.startsWith('openai/') ? model.slice(7) : model;
  return {
    url: OPENAI_BASE_URL,
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    modelId,
  };
}

export async function analyzeHand(
  gameState: GameState,
  stats: Record<string, PlayerStats>,
  onChunk: StreamCallback,
  onDone: DoneCallback,
  onError: ErrorCallback,
): Promise<void> {
  currentAbortController?.abort();
  currentAbortController = new AbortController();

  const settings = await getSettings();

  if (!settings.openRouterApiKey) {
    onError('No API key configured. Please add it in the extension settings.');
    return;
  }

  const { url, headers, modelId } = resolveEndpointAndHeaders(
    settings.openRouterApiKey,
    settings.model,
  );

  const { system, user } = buildPrompt(gameState, stats);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: modelId,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: user },
        ],
        stream: true,
        max_tokens: 600,
        temperature: 0.3,
      }),
      signal: currentAbortController.signal,
    });

    if (!response.ok) {
      const text = await response.text();
      onError(`API error ${response.status}: ${text}`);
      return;
    }

    if (!response.body) {
      onError('No response body');
      return;
    }

    await readSSEStream(response.body, onChunk, onDone, onError);
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') return;
    onError(err instanceof Error ? err.message : String(err));
  }
}

async function readSSEStream(
  body: ReadableStream<Uint8Array>,
  onChunk: StreamCallback,
  onDone: DoneCallback,
  onError: ErrorCallback,
): Promise<void> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const data = line.slice(6).trim();
        if (data === '[DONE]') { onDone(); return; }
        try {
          const parsed = JSON.parse(data);
          const content = parsed?.choices?.[0]?.delta?.content;
          if (content) onChunk(content);
        } catch {
          // malformed SSE line — skip
        }
      }
    }
    onDone();
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') return;
    onError(err instanceof Error ? err.message : String(err));
  } finally {
    reader.releaseLock();
  }
}

export function cancelAnalysis(): void {
  currentAbortController?.abort();
  currentAbortController = null;
}

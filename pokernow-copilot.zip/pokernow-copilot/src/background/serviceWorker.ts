import type { ExtMessage, ExploitRequestMessage } from '../shared/messages';
import type { GameState, PlayerStats } from '../shared/types';
import { analyzeHand, cancelAnalysis } from './aiClient';
import { buildExploitPrompt } from './promptBuilder';
import { getSettings } from '../shared/storage';
import { OPENROUTER_BASE_URL, OPENAI_BASE_URL } from '../shared/constants';

let sidePanelPort: chrome.runtime.Port | null = null;
let lastGameState: GameState | null = null;

chrome.runtime.onConnect.addListener(port => {
  if (port.name === 'sidepanel') {
    sidePanelPort = port;
    port.onDisconnect.addListener(() => { sidePanelPort = null; });
  }
});

chrome.runtime.onMessage.addListener((msg: ExtMessage, _sender, sendResponse) => {
  handleMessage(msg).catch(console.error);
  sendResponse({ ok: true });
  return true;
});

chrome.action.onClicked.addListener(async tab => {
  if (tab.id == null) return;
  await chrome.sidePanel.open({ tabId: tab.id });
});

async function handleMessage(msg: ExtMessage): Promise<void> {
  switch (msg.type) {
    case 'HAND_COMPLETE':
      lastGameState = msg.gameState;
      sendToSidePanel({ type: 'GAME_STATE_UPDATE', gameState: msg.gameState });
      break;

    case 'STATS_UPDATE':
    case 'GAME_STATE_UPDATE':
    case 'HERO_STATS_UPDATE':
      sendToSidePanel(msg);
      break;

    case 'AI_ANALYZE_REQUEST':
      await runAnalysis(msg.gameState, msg.stats);
      break;

    case 'EXPLOIT_REQUEST': {
      const exploitMsg = msg as ExploitRequestMessage;
      const target = exploitMsg.stats[exploitMsg.playerId];
      if (!target) { sendToSidePanel({ type: 'AI_STREAM_ERROR', error: 'Player not found in stats' }); break; }
      await runExploitAnalysis(target, lastGameState, exploitMsg.stats);
      break;
    }

    case 'PULL_REQUEST': {
      // Forward to the active PokerNow tab's content script
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = tabs.find(t => t.url?.includes('pokernow.com'))?.id
        ?? tabs[0]?.id;
      if (!tabId) {
        sendToSidePanel({ type: 'AI_STREAM_ERROR', error: 'No active PokerNow tab found' });
        return;
      }
      try {
        const response = await chrome.tabs.sendMessage(tabId, msg) as { gameState: GameState };
        if (response?.gameState) {
          sendToSidePanel({ type: 'PULL_RESPONSE', gameState: response.gameState });
        }
      } catch (e) {
        sendToSidePanel({
          type: 'AI_STREAM_ERROR',
          error: `Pull failed: ${e instanceof Error ? e.message : String(e)}`,
        });
      }
      break;
    }

    default:
      break;
  }
}

async function runAnalysis(
  gameState: GameState,
  stats: Record<string, PlayerStats>,
): Promise<void> {
  cancelAnalysis();
  sendToSidePanel({ type: 'AI_STREAM_START', label: 'Analyzing hand…' });
  await analyzeHand(
    gameState, stats,
    chunk => sendToSidePanel({ type: 'AI_STREAM_CHUNK', chunk }),
    ()    => sendToSidePanel({ type: 'AI_STREAM_DONE' }),
    error => sendToSidePanel({ type: 'AI_STREAM_ERROR', error }),
  );
}

async function runExploitAnalysis(
  target: PlayerStats,
  gameState: GameState | null,
  _stats: Record<string, PlayerStats>,
): Promise<void> {
  cancelAnalysis();
  const settings = await getSettings();
  if (!settings.openRouterApiKey) {
    sendToSidePanel({ type: 'AI_STREAM_ERROR', error: 'No API key configured.' });
    return;
  }

  const { system, user } = buildExploitPrompt(target, gameState);
  const isOpenRouter = settings.openRouterApiKey.startsWith('sk-or-');
  const url = isOpenRouter ? OPENROUTER_BASE_URL : OPENAI_BASE_URL;
  const modelId = isOpenRouter
    ? settings.model
    : settings.model.startsWith('openai/') ? settings.model.slice(7) : settings.model;

  sendToSidePanel({ type: 'AI_STREAM_START', label: `🎯 Exploit: ${target.displayName}` });

  try {
    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${settings.openRouterApiKey}`,
        'Content-Type': 'application/json',
        ...(isOpenRouter ? { 'HTTP-Referer': 'https://www.pokernow.com', 'X-Title': 'PokerNow Copilot' } : {}),
      },
      body: JSON.stringify({
        model: modelId,
        messages: [
          { role: 'system', content: system },
          { role: 'user',   content: user },
        ],
        stream: true, max_tokens: 400, temperature: 0.25,
      }),
    });

    if (!resp.ok) {
      const t = await resp.text();
      sendToSidePanel({ type: 'AI_STREAM_ERROR', error: `API ${resp.status}: ${t}` });
      return;
    }

    const reader = resp.body!.getReader();
    const dec = new TextDecoder();
    let buf = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n'); buf = lines.pop() ?? '';
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const d = line.slice(6).trim();
        if (d === '[DONE]') { sendToSidePanel({ type: 'AI_STREAM_DONE' }); return; }
        try {
          const content = JSON.parse(d)?.choices?.[0]?.delta?.content;
          if (content) sendToSidePanel({ type: 'AI_STREAM_CHUNK', chunk: content });
        } catch { /* skip */ }
      }
    }
    sendToSidePanel({ type: 'AI_STREAM_DONE' });
  } catch (e) {
    sendToSidePanel({ type: 'AI_STREAM_ERROR', error: String(e) });
  }
}

function sendToSidePanel(msg: ExtMessage): void {
  if (sidePanelPort) {
    try { sidePanelPort.postMessage(msg); } catch { sidePanelPort = null; }
  }
}

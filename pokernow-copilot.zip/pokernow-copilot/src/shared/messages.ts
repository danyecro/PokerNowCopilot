import type { Hand, GameState, PlayerStats, Settings } from './types';

export type MessageType =
  | 'HAND_COMPLETE'
  | 'GAME_STATE_UPDATE'
  | 'STATS_UPDATE'
  | 'HERO_STATS_UPDATE'
  | 'AI_ANALYZE_REQUEST'
  | 'AI_STREAM_CHUNK'
  | 'AI_STREAM_DONE'
  | 'AI_STREAM_ERROR'
  | 'SETTINGS_UPDATED'
  | 'PULL_REQUEST'
  | 'PULL_RESPONSE';

export interface HandCompleteMessage {
  type: 'HAND_COMPLETE';
  hand: Hand;
  gameState: GameState;
}
export interface GameStateUpdateMessage {
  type: 'GAME_STATE_UPDATE';
  gameState: GameState;
}
export interface StatsUpdateMessage {
  type: 'STATS_UPDATE';
  stats: Record<string, PlayerStats>;
}
export interface HeroStatsUpdateMessage {
  type: 'HERO_STATS_UPDATE';
  stats: PlayerStats;
}
export interface AiAnalyzeRequestMessage {
  type: 'AI_ANALYZE_REQUEST';
  gameState: GameState;
  stats: Record<string, PlayerStats>;
}
export interface AiStreamStartMessage   { type: 'AI_STREAM_START'; label?: string; }
export interface AiStreamChunkMessage   { type: 'AI_STREAM_CHUNK'; chunk: string; }
export interface AiStreamDoneMessage    { type: 'AI_STREAM_DONE'; }
export interface AiStreamErrorMessage   { type: 'AI_STREAM_ERROR'; error: string; }
export interface SettingsUpdatedMessage { type: 'SETTINGS_UPDATED'; settings: Settings; }

export interface PullRequestMessage {
  type: 'PULL_REQUEST';
  target: 'hand' | 'board' | 'pot' | 'bets' | 'all';
}
export interface PullResponseMessage {
  type: 'PULL_RESPONSE';
  gameState: GameState;
}

export interface ExploitRequestMessage {
  type: 'EXPLOIT_REQUEST';
  playerId: string;
  stats: Record<string, PlayerStats>;
}

export type MessageType =
  | 'EXPLOIT_REQUEST';

export type ExtMessage =
  | HandCompleteMessage
  | GameStateUpdateMessage
  | StatsUpdateMessage
  | HeroStatsUpdateMessage
  | AiAnalyzeRequestMessage
  | AiStreamStartMessage
  | AiStreamChunkMessage
  | AiStreamDoneMessage
  | AiStreamErrorMessage
  | SettingsUpdatedMessage
  | PullRequestMessage
  | PullResponseMessage
  | ExploitRequestMessage;

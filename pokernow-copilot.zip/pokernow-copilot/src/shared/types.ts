export type Suit = 'h' | 'd' | 'c' | 's';
export type Rank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | 'T' | 'J' | 'Q' | 'K' | 'A';
export type Street = 'preflop' | 'flop' | 'turn' | 'river' | 'showdown';
export type ActionType = 'fold' | 'check' | 'call' | 'bet' | 'raise' | 'post' | 'allin';
export type PatternTag =
  | 'Slowplays monsters'
  | 'Bluffs draws'
  | 'Bombs river'
  | 'Folds to turn pressure'
  | 'Calling station';

export interface Card {
  rank: Rank;
  suit: Suit;
}

export interface Action {
  player: string;
  street: Street;
  type: ActionType;
  amount?: number;
  isAllIn?: boolean;
  order: number;
}

export interface Hand {
  handId: string;
  handNum: number;
  startedAt: number;
  players: string[];
  positions: Record<string, string>;
  heroCards?: [Card, Card];
  board: Card[];
  actions: Action[];
  pot: number;
  winner: string[];
  showdownCards: Record<string, Card[]>;
}

export interface SeatState {
  playerId: string;
  displayName: string;
  seatIndex: number;
  stack: number;
  currentBet: number;
  position?: string;
  isHero: boolean;
  isActive: boolean;
  hasFolded: boolean;
}

export interface GameState {
  heroCards?: [Card, Card];
  board: Card[];
  pot: number;
  street: Street;
  toAct?: string;
  buttonSeat?: number;
  seats: SeatState[];
  bigBlind: number;
  smallBlind: number;
}

export interface PlayerStats {
  playerId: string;
  displayName: string;
  handsSeen: number;
  vpip: number;
  pfr: number;
  threeBet: number;
  foldToCbet: number;
  af: number;
  counters: {
    vpipOpp: number;
    vpipAct: number;
    pfrOpp: number;
    pfrAct: number;
    threeBetOpp: number;
    threeBetAct: number;
    cbetOpp: number;
    cbetFold: number;
    bets: number;
    raises: number;
    calls: number;
  };
  showdownRanges: Card[][];
  tags: PatternTag[];
  lastUpdated: number;
}

export interface PlayerNote {
  playerId: string;
  displayName: string;
  text: string;
  colorHex?: string;
  autoTags: PatternTag[];
  updatedAt: number;
}

export interface Settings {
  openRouterApiKey: string;
  model: string;
  autoAnalyze: boolean;
  showOverlays: boolean;
  showSidePanel: boolean;
}

export const DEFAULT_MODEL = 'gpt-4o';

export const AVAILABLE_MODELS = [
  // OpenAI direct (key: sk-proj-... or sk-...)
  { id: 'gpt-4o', label: 'GPT-4o (OpenAI)' },
  { id: 'gpt-4o-mini', label: 'GPT-4o Mini (OpenAI)' },
  { id: 'gpt-4.1', label: 'GPT-4.1 (OpenAI)' },
  // OpenRouter (key: sk-or-...)
  { id: 'anthropic/claude-sonnet-4-5', label: 'Claude Sonnet 4.5 (OpenRouter)' },
  { id: 'openai/gpt-4o', label: 'GPT-4o (OpenRouter)' },
] as const;

export const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1/chat/completions';
export const OPENAI_BASE_URL = 'https://api.openai.com/v1/chat/completions';

// Stat thresholds for badge coloring
export const THRESHOLDS = {
  VPIP_TIGHT: 20,
  VPIP_LOOSE: 40,
  PFR_PASSIVE: 10,
  PFR_AGGRESSIVE: 25,
  AF_PASSIVE: 1.5,
  AF_AGGRESSIVE: 3.5,
} as const;

// Min hands before showing stats/tags
export const MIN_HANDS_FOR_STATS = 5;
export const MIN_HANDS_FOR_TAGS = 10;

// Log pull timing
export const HAND_END_DEBOUNCE_MS = 600;
export const LOG_MODAL_TIMEOUT_MS = 3000;

// Storage keys
export const STORAGE_KEYS = {
  SETTINGS: 'copilot_settings',
  ALL_PLAYER_STATS: 'copilot_player_stats',
  HERO_STATS: 'copilot_hero_stats',
  SESSION_NAME_MAP: 'copilot_name_map',
  PLAYER_NOTE_PREFIX: 'player_note_',
} as const;

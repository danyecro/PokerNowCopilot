import type { PlayerNote, PlayerStats, Settings } from './types';
import { DEFAULT_MODEL, STORAGE_KEYS } from './constants';

const DEFAULT_SETTINGS: Settings = {
  openRouterApiKey: '',
  model: DEFAULT_MODEL,
  autoAnalyze: false,
  showOverlays: true,
  showSidePanel: true,
};

export async function getSettings(): Promise<Settings> {
  const result = await chrome.storage.local.get(STORAGE_KEYS.SETTINGS);
  return { ...DEFAULT_SETTINGS, ...(result[STORAGE_KEYS.SETTINGS] ?? {}) };
}
export async function setSettings(settings: Settings): Promise<void> {
  await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
}

// Stats use chrome.storage.local (accessible from content scripts + persists across sessions)
export async function getAllPlayerStats(): Promise<Record<string, PlayerStats>> {
  const result = await chrome.storage.local.get(STORAGE_KEYS.ALL_PLAYER_STATS);
  return result[STORAGE_KEYS.ALL_PLAYER_STATS] ?? {};
}
export async function saveAllPlayerStats(stats: Record<string, PlayerStats>): Promise<void> {
  await chrome.storage.local.set({ [STORAGE_KEYS.ALL_PLAYER_STATS]: stats });
}

// Hero stats stored separately
export async function getHeroStats(): Promise<PlayerStats | null> {
  const result = await chrome.storage.local.get(STORAGE_KEYS.HERO_STATS);
  return result[STORAGE_KEYS.HERO_STATS] ?? null;
}
export async function saveHeroStats(stats: PlayerStats): Promise<void> {
  await chrome.storage.local.set({ [STORAGE_KEYS.HERO_STATS]: stats });
}

export async function getPlayerNote(playerId: string): Promise<PlayerNote | null> {
  const key = STORAGE_KEYS.PLAYER_NOTE_PREFIX + playerId;
  const result = await chrome.storage.local.get(key);
  return result[key] ?? null;
}
export async function setPlayerNote(note: PlayerNote): Promise<void> {
  const key = STORAGE_KEYS.PLAYER_NOTE_PREFIX + note.playerId;
  await chrome.storage.local.set({ [key]: note });
}

// Session name map (displayName → playerId) — content-script accessible via local
export async function getSessionNameMap(): Promise<Record<string, string>> {
  const result = await chrome.storage.local.get(STORAGE_KEYS.SESSION_NAME_MAP);
  return result[STORAGE_KEYS.SESSION_NAME_MAP] ?? {};
}
export async function setSessionNameMap(map: Record<string, string>): Promise<void> {
  await chrome.storage.local.set({ [STORAGE_KEYS.SESSION_NAME_MAP]: map });
}

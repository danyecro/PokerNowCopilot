import type { Action, Card, Hand, Street } from '../shared/types';
import { parseCards } from './cardUtils';
import { tokenizeLine } from './logTokenizer';

export function parseHand(lines: string[]): Hand | null {
  let handId = '';
  let handNum = 0;
  let startedAt = Date.now();
  const players: string[] = [];
  const positions: Record<string, string> = {};
  let heroCards: [Card, Card] | undefined;
  const board: Card[] = [];
  const actions: Action[] = [];
  let pot = 0;
  const winner: string[] = [];
  const showdownCards: Record<string, Card[]> = {};
  let currentStreet: Street = 'preflop';
  let actionOrder = 0;
  let foundStart = false;

  for (const line of lines) {
    const token = tokenizeLine(line);

    switch (token.type) {
      case 'hand_start':
        foundStart = true;
        handId = token.handId;
        handNum = token.handNum;
        startedAt = Date.now();
        break;

      case 'stacks':
        for (const e of token.entries) {
          if (!players.includes(e.name)) players.push(e.name);
        }
        // Assign positions based on seat order (rough heuristic; refined by dealer info)
        break;

      case 'hero_cards': {
        const cards = parseCards(token.raw);
        if (cards.length === 2) heroCards = [cards[0], cards[1]];
        break;
      }

      case 'post':
        actions.push({
          player: token.player,
          street: 'preflop',
          type: 'post',
          amount: token.amount,
          isAllIn: false,
          order: actionOrder++,
        });
        pot += token.amount;
        if (!players.includes(token.player)) players.push(token.player);
        break;

      case 'action':
        actions.push({
          player: token.player,
          street: currentStreet,
          type: token.actionType,
          amount: token.amount,
          isAllIn: token.isAllIn,
          order: actionOrder++,
        });
        if (token.amount && (token.actionType === 'call' || token.actionType === 'bet' || token.actionType === 'raise')) {
          pot += token.amount;
        }
        break;

      case 'street': {
        const newCards = parseCards(token.cardsRaw);
        board.push(...newCards);
        currentStreet = token.street as Street;
        break;
      }

      case 'shows':
        showdownCards[token.player] = parseCards(token.cardsRaw);
        break;

      case 'collected':
        if (!winner.includes(token.player)) winner.push(token.player);
        // Use the collected amount as pot if we don't have it yet
        if (pot === 0) pot = token.amount;
        break;

      case 'hand_end':
        // end marker — we're done
        break;
    }
  }

  if (!foundStart || !handId) return null;

  return {
    handId,
    handNum,
    startedAt,
    players,
    positions,
    heroCards,
    board,
    actions,
    pot,
    winner,
    showdownCards,
  };
}

/**
 * Given all log entries from the modal, extract only the lines
 * belonging to the most recently completed hand.
 */
export function extractLastHandLines(entries: Element[]): string[] {
  // Log modal entries are NEWEST-FIRST → reverse to get chronological order
  const allLines = [...entries]
    .reverse()
    .map(el => el.querySelector('p.content')?.textContent?.trim() ?? '')
    .filter(l => l.length > 0);

  // Find the LAST "starting hand" (= most recently started hand after reversing)
  let lastStartIdx = -1;
  for (let i = allLines.length - 1; i >= 0; i--) {
    if (/^-- starting hand #/.test(allLines[i])) {
      lastStartIdx = i;
      break;
    }
  }

  if (lastStartIdx === -1) return [];
  return allLines.slice(lastStartIdx);
}

import type { Hand, PlayerStats } from '../shared/types';
import { createEmptyStats, ingestHandForPlayer } from './metrics';
import { computeTags } from './patternTagger';
import { getAllPlayerStats, saveAllPlayerStats, getHeroStats, saveHeroStats } from '../shared/storage';

const seenHandIds = new Set<string>();
let statsCache: Record<string, PlayerStats> = {};
let heroStats: PlayerStats | null = null;
let heroPlayerId: string | null = null;

// displayName → playerId, built from gameStateReader
let nameToIdMap: Record<string, string> = {};

export function updateNameMap(map: Record<string, string>): void {
  nameToIdMap = { ...nameToIdMap, ...map };
}

export function resolvePlayerId(displayName: string): string {
  return nameToIdMap[displayName] ?? displayName;
}

export function setHeroPlayerId(id: string): void {
  heroPlayerId = id;
}

/** Load persisted stats from chrome.storage.local (accessible from content scripts) */
export async function loadFromStorage(): Promise<void> {
  try {
    statsCache = await getAllPlayerStats();
    heroStats = await getHeroStats();
  } catch {
    // Storage not available in this context — continue with empty cache
    statsCache = {};
    heroStats = null;
  }
}

export function ingestHand(hand: Hand): {
  opponentStats: Record<string, PlayerStats>;
  heroStats: PlayerStats | null;
} {
  if (seenHandIds.has(hand.handId)) {
    return { opponentStats: { ...statsCache }, heroStats };
  }
  seenHandIds.add(hand.handId);

  for (const displayName of hand.players) {
    const playerId = resolvePlayerId(displayName);
    const isHero = heroPlayerId !== null && playerId === heroPlayerId;

    if (isHero) {
      const current = heroStats ?? createEmptyStats(playerId, displayName);
      const updated = ingestHandForPlayer(displayName, hand, current);
      heroStats = { ...updated, tags: computeTags(updated) };
      saveHeroStats(heroStats).catch(() => {});
    } else {
      const current = statsCache[playerId] ?? createEmptyStats(playerId, displayName);
      const updated = ingestHandForPlayer(displayName, hand, current);
      statsCache[playerId] = { ...updated, tags: computeTags(updated) };
    }
  }

  saveAllPlayerStats(statsCache).catch(() => {});
  return { opponentStats: { ...statsCache }, heroStats };
}

export function getAllStats(): Record<string, PlayerStats> {
  return { ...statsCache };
}

export function getPlayerStats(playerId: string): PlayerStats | null {
  return statsCache[playerId] ?? null;
}

export function getHeroStatsSnapshot(): PlayerStats | null {
  return heroStats;
}
